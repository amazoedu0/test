*** THEME SOURCES
In the sources folder you can find the all images that were used in the Vendy Shopify theme appeared on the demo (including banners, category images, logo and favicon icon).
 
And the eze_955_products_export.csv file you can use, if you want to import products from Vendy theme demo into your store.




*** DOCUMENTATION
Open the file within the Documentation folder to learn more about this template.Or follow the link - https://documentation.zemez.io/shopify/documentation/index.php?project=vendy&lang=en&section=introduction#
It's easy to use but you will really need it in some cases.



*** Vendy THEME
The Vendy Theme folder contains 10 themes .zip files.


Feel free to check our Shopify bestsellers:

Roxxe - Responsive Multipurpose Shopify Theme - https://themeforest.net/item/roxxe-responsive-multipurpose-shopify-theme/26554507

Torba Shopify Theme - Wholesale Website Design for Marketplace and Retail - https://themeforest.net/item/torba-wholesale-website-design-shopify-theme/28157654

LuckyDogs - Pet Care Shop Shopify Theme - https://themeforest.net/item/luckydogs-pet-care-shop-shopify-theme/28872407

Avanti - Shopify Tshirt Store Theme - https://themeforest.net/item/avanti-shopify-tshirt-store-theme/28279671

Holy Weed - Medical Marijuana Shopify Store Template for Cannabis Oil and Drug Shop - https://themeforest.net/item/holy-weed-medical-marijuana-store-shopify-template/27612507



